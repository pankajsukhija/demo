class RegionalArea {
  constructor(number, name, shortName) {
    this.number = number;
    this.name = name;
    this.shortName = shortName;
  }
}

module.exports = RegionalArea;
