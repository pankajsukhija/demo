class StationContact {
  constructor(name, shortName, email, number, phoneNumber) {
    this.name = name;
    this.shortName = shortName;
    this.email = email;
    this.number = number;
    this.phoneNumber = phoneNumber;
  }
}

module.exports = StationContact;
