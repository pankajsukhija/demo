module.exports = {
  service: {
    localSchemaFile: "./schema.graphql"
  }
};
