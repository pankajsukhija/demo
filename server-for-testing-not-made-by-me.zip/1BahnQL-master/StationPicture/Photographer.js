class Photographer {
  constructor(stationPicture) {
    this.name = stationPicture.photographer;
    this.url = stationPicture.photographerUrl;
  }
}

module.exports = Photographer;
