class MailAddress {
  constructor(city, zipcode, street) {
    this.city = city;
    this.zipcode = zipcode;
    this.street = street;
  }
}

module.exports = MailAddress;
