class Facility {
  constructor(description, type, state, location, equipmentNumber) {
    this.description = description;
    this.type = type;
    this.state = state;
    this.location = location;
    this.equipmentNumber = equipmentNumber;
  }
}

module.exports = Facility
